from setuptools import setup

setup(
    name="Paquete",
    version="0.1",
    description="Este es un pquete de ejemplo",
    author="Edwar Cruz",
    author_email="estebancruz373@gmail.com",
    scripts=[],
    packages=["paquete","paquete.adios", "paquete.hola"]
)