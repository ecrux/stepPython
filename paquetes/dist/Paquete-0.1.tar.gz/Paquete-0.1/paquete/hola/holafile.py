
class Holafile():

    def __init__(self):
        print("Hola saludos desde la clase del paquete Holafile")


def saludarHola ():
    print("Hola saludos especiales desde la funcion de saludar")