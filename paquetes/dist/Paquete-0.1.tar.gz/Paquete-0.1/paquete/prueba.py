def funcion():
    print("Hola mundo desde la funcion")


class Test():
    def __init__(self):
        print("Se ha creado una instancia de la la clase Test")


if __name__ == '__main__':
    funcion()
    Test()
