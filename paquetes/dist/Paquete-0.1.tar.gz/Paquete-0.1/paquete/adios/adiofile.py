

class Adiosfile ():

    def __init__(self):
        print("Adios a todos desde la clase adiosfile del paquete")


def despedida () : 
    print("Despedida desde la funcion de despedir")